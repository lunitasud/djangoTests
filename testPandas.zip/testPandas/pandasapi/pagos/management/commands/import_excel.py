
from csv import excel
from django.core.management.base import BaseCommand
import pandas as pd
from pagos.models import Pagos
from sqlalchemy import create_engine

class Command(BaseCommand):
    help = " Importar datos de excel"

    def handle(self, *args, **kwargs):
        
        excel_file = 'pagos.xlsx'
        df = pd.read_excel(excel_file)
        #print (df)
        engine = create_engine('sqlite:///db.sqlite3')
        df.to_sql(Pagos._meta.db_table, if_exists='replace', con=engine,index=False)