
from django.core.management.base import BaseCommand
import pandas as pd
from pagos.models import Pagos
from sqlalchemy import create_engine

class Command(BaseCommand):
    help = "Calculo de salario"

    def handle(self, *args, **kwargs):        
        engine = create_engine("sqlite:///db.sqlite3")
        