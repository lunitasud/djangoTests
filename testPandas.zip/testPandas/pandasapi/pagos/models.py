from django.db import models

# Create your models here.
class Pagos(models.Model):
    cedula = models.TextField(max_length=20)
    sal_base = models.DecimalField(max_digits=30,decimal_places=2)
    parafiscal = models.DecimalField(max_digits=30,decimal_places=2)
    sal_neto = models.DecimalField(max_digits=30,decimal_places=2)
    extras = models.DecimalField(max_digits=30,decimal_places=2)