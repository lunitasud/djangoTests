import string
from turtle import title
from django.db import models

# Create your models here.

class OrderList(models.Model):
    arraylist = models.TextField(max_length=500)
    SIZE = len(str(arraylist).split(','))
    size = models.IntegerField(max_length=5,default=SIZE)
    
    def order(lista):
        list1 = lista
        if len(list1) > 1:
            mid = len(list1) // 2
            left = list1[:mid]
            right = list1[mid:]

            # Recursive call on each half
            OrderList.order(left)
            OrderList.order(right)

            # Two iterators for traversing the two halves
            i = 0
            j = 0
            
            # Iterator for the main list
            k = 0
            
            while i < len(left) and j < len(right):
                if int(left[i] )<= int(right[j]):
                    # The value from the left half has been used
                    list1[k] = int(left[i])
                    # Move the iterator forward
                    i += 1
                else:
                    list1[k] = int(right[j])
                    j += 1
                # Move to the next slot
                k += 1

            # For all the remaining values
            while i < len(left):
                list1[k] = left[i]
                i += 1
                k += 1

            while j < len(right):
                list1[k]=right[j]
                j += 1
                k += 1
        return list1
    
class Roles(models.Model):
    id_role = models.IntegerField(max_length=10)
    name_role = models.TextField(max_length=200)
    permission_role = models.TextField(max_length=500)

class Users(models.Model):
    identification = models.TextField(max_length=255)
    name  = models.TextField(max_length=255)
    lastname = models.TextField(max_length=255)
    email = models.TextField(max_length=255)
    dateCreated = models.DateTimeField(auto_now_add=True)
    role_usuario = models.ForeignKey(Roles,
                                    on_delete=models.CASCADE,
                                    null=False,
                                    blank=False)
class Cases(models.Model):
    description = models.TextField(max_length=255)
    dateCase =  models.DateTimeField(auto_now_add=True)
    state = models.CharField(max_length=2)
    user_reporter = models.ForeignKey(Users,
                                    on_delete=models.CASCADE,
                                    null=False,
                                    blank=False)
