from rest_framework import serializers
from .models import Users,Cases,Roles,OrderList

class UsersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = ('id','identification', 'name', 'lastname','email','dateCreated','role_usuario')
        read_only_fields = ('id','dateCreated',)

class CasesSerializer(serializers.ModelSerializer):
     class Meta:
        model = Cases
        fields = ('id','description', 'state','dateCase','user_reporter')
        read_only_fields = ('id','dateCase',)

class RolesSerializer(serializers.ModelSerializer):
     class Meta:
        model = Roles
        fields = ('id','id_role', 'name_role','permission_role')
        read_only_fields = ('id',)

class OrderListSerializer(serializers.ModelSerializer):
     class Meta:
        model = OrderList
        fields = ('id','arraylist','size')
        read_only_fields = ('id', 'size',)
     