from  projects.models import Users,Roles,OrderList,Cases
from rest_framework import viewsets,permissions
from .serializers import UsersSerializer,CasesSerializer,RolesSerializer,OrderListSerializer

class UsersViewSet (viewsets.ModelViewSet):
    queryset = Users.objects.all()
    permissions_classes = [permissions.AllowAny]
    serializer_class = UsersSerializer

class RolesViewSet (viewsets.ModelViewSet):
    queryset = Roles.objects.all()
    permissions_classes = [permissions.AllowAny]
    serializer_class = RolesSerializer

class OrderListViewSet (viewsets.ModelViewSet):
    queryset = OrderList.objects.all()
    permissions_classes = [permissions.AllowAny]
    serializer_class = OrderListSerializer

class CasesViewSet (viewsets.ModelViewSet):
    queryset = Cases.objects.all()
    permissions_classes = [permissions.AllowAny]
    serializer_class = CasesSerializer
