from django.urls import URLPattern


from rest_framework import routers
from .api import UsersViewSet,CasesViewSet,RolesViewSet, OrderListViewSet

router = routers.DefaultRouter()

router.register("api/users",UsersViewSet,"users")
router.register("api/cases",CasesViewSet,"cases")
router.register("api/roles",RolesViewSet,"roles")
router.register("api/list",OrderListViewSet,"list")
urlpatterns = router.urls